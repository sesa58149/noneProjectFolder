﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;
using System.Text;
using ConceptArchitect.UI.Default;

namespace ConceptArchitect.UI.Core
{
    public class UIFactoryBuilder
    {
        public static Exception error = null;
        public static UIFactory Create()
        {
            error = null;
            try
            {
                var theme = ConfigurationManager.AppSettings["theme"];
                var dll = string.Format("{0}Themes\\{1}.dll", AppDomain.CurrentDomain.BaseDirectory, theme);

                Assembly asm = Assembly.LoadFile(dll); //C++ LoadLibrary

                Type factory = typeof(UIFactory);

                foreach (Type type in asm.GetTypes())
                {
                    if (factory.IsAssignableFrom(type)) //if current type is a sub class of factory
                    {
                        return (UIFactory)Activator.CreateInstance(type);
                    }
                }
                error = new ArgumentException("Not a Plugin");
            }
            catch(Exception ex)
            {
                error = ex;
            }
            //A default or fallback dependency
            return new DefaultFactory() ;

        }
    }
}
