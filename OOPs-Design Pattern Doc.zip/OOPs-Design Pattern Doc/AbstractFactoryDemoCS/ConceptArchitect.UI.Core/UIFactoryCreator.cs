﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Reflection;
using ConceptArchitect.UI.Default;

namespace ConceptArchitect.UI.Core
{
    public class UIFactoryCreator
    {
        public static Exception  Error { get; set; }
        public static UIFactory CreateFactory()
        {
            try
            {
                Error = null;
                string themeName = ConfigurationManager.AppSettings["theme"];
                string asmPath = string.Format("{0}Plugins\\{1}.dll", AppDomain.CurrentDomain.BaseDirectory, themeName);

                Assembly asm = Assembly.LoadFile(asmPath);

                return CreateFactory(asm);
            }
            catch (Exception ex)
            {
                Error = ex;
                return new DefaultFactory(); //default or fall back dependency
            }

            
        }

        public static UIFactory CreateFactory(Assembly asm)
        {
            Type absFactory=typeof(UIFactory);
 	        foreach(var type in asm.GetTypes())
            {
                if(absFactory.IsAssignableFrom(type))
                {
                    return (UIFactory)Activator.CreateInstance(type);
                }
            }

            throw new InvalidOperationException("Current assembly is not a UI theme");
        }
    }
}
