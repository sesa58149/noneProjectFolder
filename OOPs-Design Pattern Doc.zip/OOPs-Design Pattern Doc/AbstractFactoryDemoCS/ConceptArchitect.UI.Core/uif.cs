﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Reflection;
using ConceptArchitect.UI.Default;

namespace ConceptArchitect.UI.Core
{
    public class UIFactories
    {
        public static  Exception Error;
        public static UIFactory createFactory()
        {
            Error = null;
            try
            {
                String themeName = ConfigurationManager.AppSettings["theme"];
                String asmPath = string.Format("{0}themes\\{1}.dll", AppDomain.CurrentDomain.BaseDirectory,
                                        themeName);

                Assembly asm = Assembly.LoadFile(asmPath);

                foreach (Type t in asm.GetTypes())
                {
                    if (typeof(UIFactory).IsAssignableFrom(t))
                        return (UIFactory)Activator.CreateInstance(t);
                }

            }
            catch (Exception ex)
            {
                Error = ex;
            }
            return new DefaultFactory();


        }
    }
}