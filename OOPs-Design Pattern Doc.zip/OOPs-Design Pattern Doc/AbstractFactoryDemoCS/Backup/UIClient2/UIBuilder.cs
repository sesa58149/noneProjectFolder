﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;


namespace UIClient
{
    public class UIBuilder
    {
        public static UIForm BuildUI(UIComponentFactory ui)
        {
            UIPanel p1 = ui.Create<UIPanel>();
            p1.Add(ui.Create<UITextBox>());
            p1.Add(ui.Create<UIButton>());
            p1.Add(ui.Create<UIButton>());

            UIPanel p2 = ui.Create<UIPanel>();
            p2.Add(ui.Create<UITextBox>());
            p2.Add(ui.Create<UITextBox>());
            p2.Add(ui.Create<UIButton>("pushbutton"));

            UIForm frm = ui.Create<UIForm>();
            frm.Add(p1);
            frm.Add(p2);
            frm.Add(ui.Create<UIButton>());
            UIComponent slider = ui.Create<UIComponent>("slider");

            frm.Add(slider);

            return frm;

        }
    }
}
