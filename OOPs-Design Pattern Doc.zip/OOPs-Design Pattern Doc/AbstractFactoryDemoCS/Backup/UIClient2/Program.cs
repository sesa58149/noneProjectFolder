﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace UIClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //UIFactory ui = new ConceptArchitect.UI.Metal.MetalFactory();
            //UIFactory ui = new ConceptArchitect.UI.Wood.WoodFactory();
            //UIFactory ui = null;
            //UIFactory ui = UIFactories.Create();

            UIComponentFactory ui = UIComponentFactories.Create();

            

            if (UIFactories.Error != null)
            {
                Console.WriteLine("*** error in theme. Default loaded ***");
            }


            UIForm frm = UIBuilder.BuildUI(ui);
            frm.Show();

            Console.ReadLine();

        }
    }
}
