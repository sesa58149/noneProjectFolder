﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConceptArchitect.UI.Core
{
    public abstract class UIComponent
    {

        public virtual void Draw(String indent)
        {
            Console.WriteLine("{0}{1} drawn",indent,this.GetType().Name);
        }
    }


}








