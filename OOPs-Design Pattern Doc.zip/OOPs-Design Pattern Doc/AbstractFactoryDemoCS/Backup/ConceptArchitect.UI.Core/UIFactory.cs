﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConceptArchitect.UI.Core
{
    public abstract class UIFactory
    {
        public abstract UIForm CreateForm();
        public abstract UITextBox CreateTextBox();
        public abstract UIButton CreateButton();
        public abstract UIPanel CreatePanel();
    }

    
}
