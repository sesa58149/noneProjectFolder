﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConceptArchitect.UI.Core
{
    public abstract class UIButton:UIComponent
    {
    }
}
