﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace ConceptArchitect.UI.Default
{
    public class DefaultForm : UIForm { }

    public class DefaultButton : UIButton { }

    public class DefaultTextBox : UITextBox { }

    public class DefaultPanel : UIPanel { }


    public class DefaultFactory : UIFactory
    {
        public override UIForm CreateForm()
        {
            return new DefaultForm();
        }

        public override UITextBox CreateTextBox()
        {
            return new DefaultTextBox();
        }

        public override UIButton CreateButton()
        {
            return new DefaultButton();
        }

        public override UIPanel CreatePanel()
        {
            return new DefaultPanel();
        }
    }



}
