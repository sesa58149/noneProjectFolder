﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConceptArchitect.UI.Core
{
    public abstract class UIContainer:UIComponent
    {
        List<UIComponent> components = new List<UIComponent>();
        
        public virtual void Add(UIComponent component)
        {
            components.Add(component);
        }

        public override void Draw(String indent)
        {
            base.Draw(indent); //draws itself
            foreach (UIComponent component in components) //draws all added children
                component.Draw(indent + "\t");
        }

        public void Show()
        {
            this.Draw("");
        }
    }
}








