﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Reflection;
using ConceptArchitect.UI.Default;

namespace ConceptArchitect.UI.Core
{
    public class UIFactories
    {
        private static Exception error;
        public static Exception GetError() { return error; }
        public static UIFactory CreateFactory()
        {
            try
            {
                error = null;
                string uiName = ConfigurationManager.AppSettings["ui"];
                string asmPath = string.Format("{0}plugins\\{1}.dll",
                                    AppDomain.CurrentDomain.BaseDirectory,
                                    uiName);

                Assembly asm = Assembly.LoadFile(asmPath);


                return CreateFactory(asm);
            }
            catch (Exception ex)
            {
                //you may want to log the error
                error = ex;
                return new DefaultFactory();
            }
        }

        public static UIFactory CreateFactory(Assembly asm)
        {
            Type factory = typeof(UIFactory);

            foreach (Type t in asm.GetTypes())
            {
                if (factory.IsAssignableFrom(t))
                    return (UIFactory)Activator.CreateInstance(t);
            }

            throw new ApplicationException("invalid ui plugin");
        }

    }
}
