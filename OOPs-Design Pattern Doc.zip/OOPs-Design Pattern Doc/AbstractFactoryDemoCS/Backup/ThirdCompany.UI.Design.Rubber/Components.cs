﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace ThirdCompany.UI.Design.Rubber
{
    public class RubberForm : UIForm { }

    public class RubberButton : UIButton { }

    public class RubberTextBox : UITextBox { }

    public class RubberPanel : UIPanel { }


    public class RubberFactory : UIFactory
    {
        public override UIForm CreateForm()
        {
            return new RubberForm();
        }

        public override UITextBox CreateTextBox()
        {
            return new RubberTextBox();
        }

        public override UIButton CreateButton()
        {
            return new RubberButton();
        }

        public override UIPanel CreatePanel()
        {
            return new RubberPanel();
        }
    }



}
