﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace ConceptArchitect.UI.Wood
{
    public class WoodForm : UIForm { }

    public class WoodTextBox : UITextBox { }

    public class WoodButton : UIButton { }

    public class WoodPanel : UIPanel { }

    public class WoodFactory : UIFactory
    {
        public override UIForm CreateForm()
        {
            return new WoodForm();
        }

        public override UITextBox CreateTextBox()
        {
            return new WoodTextBox();
        }

        public override UIButton CreateButton()
        {
            return new WoodButton();
        }

        public override UIPanel CreatePanel()
        {
            return new WoodPanel();
        }
    }
}
