﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace UIClient
{
    public class UIBuilder
    {
        public static UIForm BuildUI(UIFactory ui)
        {
            UIPanel p1 = ui.CreatePanel();
            p1.Add(ui.CreateTextBox());
            p1.Add(ui.CreateButton());
            p1.Add(ui.CreateButton());

            UIPanel p2 = ui.CreatePanel();
            p2.Add(ui.CreateTextBox());
            p2.Add(ui.CreateTextBox());
            p2.Add(ui.CreateButton());

            UIForm frm = ui.CreateForm();
            frm.Add(p1);
            frm.Add(p2);
            frm.Add(ui.CreateButton());

            return frm;

        }
    }
}
