﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace UIClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //UIFactory ui = null;
            //UIFactory ui = new ConceptArchitect.UI.Metal.MetalFactory();
            //UIFactory ui = new ConceptArchitect.UI.Wood.WoodFactory();

            UIFactory ui = UIFactories.CreateFactory();
            if (UIFactories.GetError() != null)
            {
                Console.WriteLine("*** ERROR LOADING RIGHT COMPONENTS ***");
                Console.WriteLine("Using the default components...");
            }

            UIForm frm = UIBuilder.BuildUI(ui);

            frm.Show();

            Console.ReadLine();

        }
    }
}
