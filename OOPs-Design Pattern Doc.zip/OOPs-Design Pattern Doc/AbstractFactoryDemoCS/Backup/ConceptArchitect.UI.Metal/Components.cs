﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace ConceptArchitect.UI.Metal
{
    public class MetalForm : UIForm { }

    public class MetalTextBox : UITextBox { }

    
    public class MetalButton : UIButton { }

    
    public class MetalPushButton : UIButton { }

    public class MetalPanel : UIPanel { }

    public class MetalFactory : UIFactory
    {
        public override UIForm CreateForm()
        {
            return new MetalForm();
        }

        public override UITextBox CreateTextBox()
        {
            return new MetalTextBox();
        }

        public override UIButton CreateButton()
        {
            return new MetalButton();
        }

        public override UIPanel CreatePanel()
        {
            return new MetalPanel();
        }
    }
}
