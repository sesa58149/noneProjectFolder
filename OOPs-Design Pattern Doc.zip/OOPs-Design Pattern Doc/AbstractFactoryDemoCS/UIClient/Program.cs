﻿using System;
using System.Collections.Generic;
using System.Text;
using ConceptArchitect.UI.Core;

namespace UIClient
{
    class Program
    {
        static void Main(string[] args)
        {
            
           // UIFactory ui = new ConceptArchitect.UI.Wood.WoodFactory();

           //UIFactory ui = new ConceptArchitect.UI.Metal.MetalFactory();

            UIFactory ui = UIFactoryBuilder.Create();
            
            if(UIFactoryBuilder.error!=null)
            {
                Console.WriteLine("Error Loadign Plugin");
               // return;
            }

            UIForm frm = UIBuilder.BuildUI(ui); //method based DI

            frm.Show();

            Console.ReadLine();

        }
    }
}
