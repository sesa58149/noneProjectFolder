﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Drawing;

namespace PointTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Point p1 = Point.GetCartisian(3, 4); //new Point(3, 4);
            Console.WriteLine(p1);

            Point p2 = Point.GetVector(5, 45);  // new Point(5, 45);

            Console.WriteLine(p2);

            Point p3 = Point.GetCartisian(3, 4);
            Console.WriteLine(p3);



        }
    }
}
