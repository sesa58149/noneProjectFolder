﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Drawing;

namespace RectangleSquareDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Rectangle[] shapes = {
                                    RectangleCreator.Create(3,4),    //new ProperRectangle(3, 4),
                                    RectangleCreator.Create(8,8),                //new ProperRectangle(8,8),
                                    RectangleCreator.CreateSquare(7),                //new Square(7),
                                    //new ProperRectangle(8,8),
                                    RectangleCreator.Create(8,2)                //new ProperRectangle(8,2)
                                     };

            for(int i=0;i<shapes.Length;i++)
            {
                TestRectangle(shapes[i]);
            }


        }

        static void TestRectangle(Rectangle shape)
        {
            shape.Draw();
            Console.WriteLine("Area={0} \tPerimeter={1}",shape.Area(), shape.Perimeter());


            if (shape is ProperRectangle)  
            Console.WriteLine("Orientation={0}",((ProperRectangle)shape).GetOrientation());
            Console.WriteLine("\n\n");
        }
    }
}
