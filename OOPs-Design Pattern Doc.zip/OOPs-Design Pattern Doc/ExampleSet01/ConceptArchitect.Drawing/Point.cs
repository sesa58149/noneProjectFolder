﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{
    public class Point
    {
        double x, y;

        public double X() { return x; }
        public double Y() { return y; }

        public double R() { return Math.Sqrt(x * x + y * y); }

        public double Theta()
        {
            double rad = Math.Atan(y / x);
            return rad * 180 / Math.PI;
        }

        private Point(double x,double y)
        {
            this.x = x;
            this.y = y;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("DEBUG: Point {0} {1} Created...",x,y);
            Console.ResetColor();
        }

        //public Point(double r,double theta)
        //{
        //    double rad = Math.PI * theta / 180;
        //    this.x = Math.Cos(rad);
        //    this.y = Math.Sin(rad);
        //}

        public static Point GetCartisian(double x,double y)
        {
            return GetPoint(x, y);
        }

        public static Point GetVector(double r,double theta)
        {
            double rad = Math.PI * theta / 180;
            double x =r* Math.Cos(rad);
            double y =r* Math.Sin(rad);
            return GetPoint(x, y);
        }

        static List<Point> cache = new List<Point>();

        private static Point GetPoint(double x,double y)
        {
            for (int i = 0; i < cache.Count;i++ )
            {
                if (cache[i].x == x && cache[i].y == y)
                    return cache[i];
            }


            Point p= new Point(x, y);
            cache.Add(p);

            return p;
        }


        public override string ToString()
        {
            return string.Format("Point(x={0},y={1},r={2},theta={3})", x, y, R(), Theta());
        }

    }
}
