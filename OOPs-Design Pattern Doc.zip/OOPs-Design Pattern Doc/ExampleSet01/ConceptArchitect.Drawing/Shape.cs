﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{
    public abstract class Rectangle
    {
        public abstract double Area();
        public abstract double Perimeter();
        public abstract void Draw();
    }
}
