﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{

    public enum Orientation { Sleeping, Standing}

    public class ProperRectangle:Rectangle
    {
        double width, height;

        internal ProperRectangle(double width,double height)
        {
            this.width = width;
            this.height = height;
        }

        public override double Perimeter()
        {
            return 2 * (width + height);
        }

        public override double Area()
        {
            return width * height;
        }

        public override void Draw()
        {
            Console.WriteLine("Rectangle [{0},{1}] drawn",width,height);
        }

        public virtual Orientation GetOrientation()
        {
            if (width > height)
                return Orientation.Sleeping;
            else
                return Orientation.Standing;

        }
    }
}





