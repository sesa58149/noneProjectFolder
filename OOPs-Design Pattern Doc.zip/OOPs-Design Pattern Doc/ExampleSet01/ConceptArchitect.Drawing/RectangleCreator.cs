﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{
    public class RectangleCreator
    {
        public static Rectangle Create(double x,double y)
        {
            if (x == y)
                return new Square(x);
            else
                return new ProperRectangle(x, y);
        }

        public static Rectangle CreateSquare(double x)
        {
            return new Square(x);
        }
    }
}
