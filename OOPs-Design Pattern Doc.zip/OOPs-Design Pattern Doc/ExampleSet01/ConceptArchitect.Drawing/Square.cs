﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{
    public class Square:Rectangle
    {
        double side;
        internal Square(double side)
        {
            this.side = side;
        }
        public override double Area()
        {
            return side * side;
        }

        public override double Perimeter()
        {
            return 4 * side;
        }

        public override void Draw()
        {
            Console.WriteLine("Square [{0}] drawn",side);
        }
    }
}
