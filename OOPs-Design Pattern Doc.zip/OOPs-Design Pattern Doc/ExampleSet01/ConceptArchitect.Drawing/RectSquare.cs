﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Drawing
{
    public class RectSquare :   ProperRectangle
    {
        public RectSquare(double side):base(side,side)
        {

        }

        public override Orientation GetOrientation()
        {
            throw new InvalidOperationException("Orientation is Not Supported");
        }
    }
}
