﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public class Input
    {
        public static T Read<T>(string prompt)
        {
            try 
            { 
                Console.Write(prompt);
                string str=Console.ReadLine();
                return (T)Convert.ChangeType(str, typeof(T));
            }
            catch(Exception e)
            {
                return default(T);
            }
    }
}
