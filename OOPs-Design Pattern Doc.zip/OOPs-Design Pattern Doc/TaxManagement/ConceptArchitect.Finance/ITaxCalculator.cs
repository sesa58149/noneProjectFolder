﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public enum Gender{Male,Female}
    public interface ITaxCalculator
    {
        int Calculate(Gender gender, int income, int expense, int investment);
    }


}
