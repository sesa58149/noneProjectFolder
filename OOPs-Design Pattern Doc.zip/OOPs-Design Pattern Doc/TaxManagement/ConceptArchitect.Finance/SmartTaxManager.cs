﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public class SmartTaxManager
    {
        public IFinancialInfoSource Source { get; set; }
        public ITaxSubmitter Submitter { get; set; }
        
        public void FileTax(string pan,ITaxCalculator calc, int year)
        {
            FinanceInfo f = Source.GetFinancialInfo(year, pan);
            int t = calc.Calculate(f.Gender, f.Income, f.Expense, f.Investment);
            Submitter.SubmitTax(pan, year, t);
        }
    }
}
