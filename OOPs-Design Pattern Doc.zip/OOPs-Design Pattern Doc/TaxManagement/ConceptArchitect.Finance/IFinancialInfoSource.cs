﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public class FinanceInfo
    {
        public Gender Gender { get; set; }
        public string PanCard { get; set; }
        public int Income { get; set; }
        public int Expense { get; set; }
        public int Investment { get; set; }


    }
    public interface IFinancialInfoSource
    {
        FinanceInfo GetFinancialInfo(int year, string pan);
    }

    public class RandomFinanceSource:IFinancialInfoSource
    {

        public FinanceInfo GetFinancialInfo(int year, string pan)
        {
            Random r = new Random();
            return new FinanceInfo()
            {
                PanCard=pan,
                Gender=Char.ToLower(pan[0])=='m'?Gender.Male:Gender.Female,
                Income=r.Next(100000,500000),
                Expense=r.Next(20000,40000),
                Investment=r.Next(10000,40000)
            };
        }
    }

    public class ConsoleInputFinanceSource : IFinancialInfoSource
    {

        public FinanceInfo GetFinancialInfo(int year, string pan)
        {
            Random r = new Random();
            return new FinanceInfo()
            {
                PanCard = pan,
                Gender = Char.ToLower(pan[0]) == 'm' ? Gender.Male : Gender.Female,
                Income = Input.Read<int>("income? "),
                Expense = Input.Read<int>("expense? "),
                Investment = Input.Read<int>("investment? ")
            };
        }
    }
}
