﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public class TaxCalculator2013:ITaxCalculator
    {
       
        public int Calculate(Gender gender, int income, int expense, int investment)
        {
            int t = (income - expense - investment) / 15;
            if (gender == Gender.Female)
                t *= 9 / 10;
            return t;
        }

    }

    public class TaxCalculator2014 : ITaxCalculator
    {

        public int Calculate(Gender gender, int income, int expense, int investment)
        {
            investment = investment > 100000 ? 100000 : investment;
            expense /= 2;

            int t = (income - expense - investment) / 10;
            if (gender == Gender.Female)
                t *= 9 / 10;
            return t;
        }

    }
}
