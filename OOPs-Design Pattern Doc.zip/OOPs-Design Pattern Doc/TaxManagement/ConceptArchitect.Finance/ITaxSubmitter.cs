﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Finance
{
    public interface ITaxSubmitter
    {
        void SubmitTax(string pan, int year, int tax);
    }

    public class ConsoleTaxSubmitter:ITaxSubmitter
    {

        public void SubmitTax(string pan, int year, int tax)
        {
            Console.WriteLine("PAN:{0}\tYear={1}\tTax={2}",pan,year,tax);
        }

    }
}
