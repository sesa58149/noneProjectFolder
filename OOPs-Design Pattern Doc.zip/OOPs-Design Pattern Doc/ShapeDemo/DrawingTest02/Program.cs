﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConceptArchitect.Drawing2;
using DrawingTest02;

namespace DrawTest02
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape[] shapes ={
                                new Circle(8),   
                                new Triangle(3,4,5),
                                new Rectangle(4,3)  
                            };

            foreach (var shape in shapes)
            {
                Console.WriteLine("\t\tshape is "+shape.GetType().Name);
                shape.Draw();
                Console.WriteLine("Area="+shape.Area);
                Console.WriteLine("Perimeter="+shape.Perimeter);
                Console.WriteLine();
            }

        }
    }
}
