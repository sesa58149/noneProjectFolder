﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConceptArchitect.Drawing;

namespace DrawTest01
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape[] shapes ={
                                new Shape(8),   //A circle
                                
                                new Shape(4,3)  //A Rectangle
                            };

            foreach (var shape in shapes)
            {
                Console.WriteLine("\t\tshape is "+shape.Type);
                shape.Draw();
                Console.WriteLine("Area="+shape.Area);
                Console.WriteLine("Perimeter="+shape.Perimeter);
                Console.WriteLine();
            }

        }
    }
}
