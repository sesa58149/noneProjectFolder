﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptArchitect.Drawing
{
    public enum ShapeType 
    { 
         Circle, 
         Rectangle
    }

    public class Shape
    {
        double radius;
        double width, height;
        
        public ShapeType Type { get; private set; }

        public Shape(double radius)
        {
            this.radius = radius;
            Type = ShapeType.Circle;
        }

        public Shape(double width,double height)
        {
            this.width = width;
            this.height = height;
            Type = ShapeType.Rectangle;
        }

        public double Area
        {
            get
            {
                double a=0;
                
                if (Type == ShapeType.Rectangle)
                    a = width * height;
                else
                    a = Math.PI * radius * radius;

                return a;
            }
        }

        public double Perimeter
        {
            get
            {
                double p = 0;
                switch (Type)
                {
                    case ShapeType.Rectangle:
                        p = 2 * (width + height); 
                        break;
                    case ShapeType.Circle: 
                        p = 2 * Math.PI * radius;
                        break;
                };
                return p;
            }
        }

        public void Draw()
        { 
            if(Type==ShapeType.Rectangle)
                Console.WriteLine("Rectangle [{0},{1}] drawn",width,height);
            else
                Console.WriteLine("Circle ({0}) drawn",radius);

        }

    }
}



