﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptArchitect.Drawing
{
    //public enum ShapeType { Circle, Rectangle }

   // public class Shape
   // {
        
        //public ShapeType Type { get; private set; }

       
        //Type = ShapeType.Circle;
       

        
        //Type = ShapeType.Rectangle;
        


       
    //   if (Type == ShapeType.Rectangle)
    //   else

    //switch (Type)
    //{
    //    case ShapeType.Rectangle:
    //        break;
    //    case ShapeType.Circle:
    //        break;

    //};

    //        if(Type==ShapeType.Rectangle)
    //        else





    //}
}



