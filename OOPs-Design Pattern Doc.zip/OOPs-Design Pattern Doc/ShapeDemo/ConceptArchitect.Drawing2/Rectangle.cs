﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptArchitect.Drawing2
{
    public class Rectangle :Shape
    {        
        double width, height;
        public Rectangle(double width,double height)
        {
            this.width = width;
            this.height = height;
            
        }

        public override double Area
        {
            get
            {
                double a = 0;
         
                 a = width * height;
         
                return a;
            }
        }

        public override double Perimeter
        {
            get
            {
                double p = 0;
                p = 2 * (width + height);
                return p;
            }
        }

        public override void Draw()
        {
                Console.WriteLine("Rectangle [{0},{1}] drawn", width, height);
        }

    }

    
}
