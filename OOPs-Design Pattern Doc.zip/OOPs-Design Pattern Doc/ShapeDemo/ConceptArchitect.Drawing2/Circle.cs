﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConceptArchitect.Drawing2
{
    public class Circle:Shape
    {
        double radius;
        public Circle(double radius)
        {
            this.radius = radius;

        }

        public override double Area
        {
            get
            {
                double a = 0;
                a = Math.PI * radius * radius;
                return a;
            }
        }

        public override double Perimeter
        {
            get
            {
                double p = 0;

                p = 2 * Math.PI * radius;

                return p;
            }
        }
        public override void Draw()
        {
            Console.WriteLine("Circle ({0}) drawn", radius);
        }

    }
}
