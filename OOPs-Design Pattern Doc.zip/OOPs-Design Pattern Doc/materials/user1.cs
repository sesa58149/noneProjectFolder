//User Management UI

void RegisterButton_Click()
{
	//User user=new User(name,email,password,hq,ha);
 			//insert into userDb...

	User user=UserManager.CreateUser(name,email,password,hq,ha);

}


void LoginButton_Click()
{
	//are we talking about a new user here!!!
	//User user=new User(email,password);		//select * from userDb where ...


	User user=UserManager.GetUser(email,password);
}