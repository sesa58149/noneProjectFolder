

class UserManager
{

	List<User> GetAllUsers()
	{

		SqlConnection con=new SqlConnection(conStr);

		SqlCommand cmd=new SqlCommand(con);

		con.Open();

		cmd.CommandText="select * from Users";

		SqlDataReader reader=cmd.ExecuteReader();

		while(reader.Read)
		{
			//convert reader to User
		}

	}

}