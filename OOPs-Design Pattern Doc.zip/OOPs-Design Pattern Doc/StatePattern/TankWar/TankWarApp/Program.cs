﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Games.TankWar;

namespace TankWarApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ITank tank = new SmartTank();
            //object[] modes = { TankMode.Attacking, TankMode.Defending, TankMode.Gorilla };
            object[] modes = { TankBehaviors.Attack, TankBehaviors.Defend, new GorillaBehavior() };
            foreach (object mode in modes)
            {
                tank.Mode = mode;
                TestTank(tank);
            }

        }

        private static void TestTank(ITank tank)
        {
            Console.WriteLine("Tank Mode is "+tank.Mode);
            tank.Move();
            tank.Attack();
            tank.Defend();
            Console.WriteLine("\t---");
        }
    }
}
