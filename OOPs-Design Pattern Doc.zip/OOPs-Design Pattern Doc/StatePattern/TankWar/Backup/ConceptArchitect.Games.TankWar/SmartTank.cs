﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Games.TankWar
{
    public interface ITankBehavior
    {
        void AttackBehavior();
        void DefendBehavior();
        void MoveBehavior();
    }

    public class SmartTank:ITank
    {
        
        private ITankBehavior _state;
        public ITankBehavior State
        {
            get { return _state; }

            set { _state = value; }
        }
        

        public object Mode
        {
            get
            {
                return _state;
            }

            set
            {
                if (value is ITankBehavior)
                    _state = (ITankBehavior) value;
            }

        }



        public void Attack()
        {
            State.AttackBehavior();
        }

        public void Defend()
        {
            State.DefendBehavior();
        }

        public void Move()
        {
            State.MoveBehavior();
        }



        
    }

    public class AttackingBehavior : ITankBehavior
    {
        

        public void AttackBehavior()
        {
            Console.WriteLine("Fire at Enemy");
        }

        public void DefendBehavior()
        {
            Console.WriteLine("Cover Fire ");
        }

        public void MoveBehavior()
        {
            Console.WriteLine("Run at Enemy. CRUSH them");
        }

        
    }

    public class DefendingBehavior : ITankBehavior
    {


        public void AttackBehavior()
        {
            Console.WriteLine("Wait. Firing gives away our position");
        }

        public void DefendBehavior()
        {
            Console.WriteLine("Hide. Save yourself ");
        }

        public void MoveBehavior()
        {
            Console.WriteLine("Run away from enemy");
        }


    }

    public class GorillaBehavior : ITankBehavior
    {


        public void AttackBehavior()
        {
            Console.WriteLine("Fire");
            MoveBehavior();
        }

        public void DefendBehavior()
        {
            Console.WriteLine("Duck ");
        }

        public void MoveBehavior()
        {
            Console.WriteLine("Move hapazard. Keep enemy guessing");
        }


    }

    public class SmartBehavior : ITankBehavior
    {
        #region ITankBehavior Members

        public void AttackBehavior()
        {
            Console.WriteLine("Think and Fire!!!");
        }

        public void DefendBehavior()
        {
            Console.WriteLine("Keep changing position");
        }

        public void MoveBehavior()
        {
            Console.WriteLine("Plan before moving. Move as planned");
        }

        #endregion
    }

    public class TankBehaviors
    {
        public static readonly ITankBehavior Attack = new AttackingBehavior();
        public static readonly ITankBehavior Defend = new DefendingBehavior();
        public static readonly ITankBehavior Gorialla = new GorillaBehavior();
    }
}
