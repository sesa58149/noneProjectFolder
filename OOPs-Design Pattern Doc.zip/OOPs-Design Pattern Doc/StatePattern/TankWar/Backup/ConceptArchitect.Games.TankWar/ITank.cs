﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Games.TankWar
{
    public interface ITank
    {
        void Attack();
        void Defend();
        void Move();

        object Mode { get; set; }
    }
}
