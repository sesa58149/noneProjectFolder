﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Games.TankWar
{
    public enum TankMode { Attacking, Defending, Gorilla };

    public class StupidTank:ITank
    {
    
        private TankMode _mode=TankMode.Attacking;
        public object Mode
        {
            get { return _mode; }

            set 
            { 
                if(value is TankMode)
                    _mode =(TankMode) value; 
            }
        }
	
        public void Attack()
        {
            switch (_mode)
            {
                case TankMode.Attacking:
                    Console.WriteLine("Fire at enemy");
                    break;
                case TankMode.Defending:
                    Console.WriteLine("Wait and watching. attacking may give our position");
                    break;
                case TankMode.Gorilla:
                    Console.WriteLine("Fire at enemy");
                    Move();
                    break;
            }
        }

        public void Defend()
        {
            switch (_mode)
            {
                case TankMode.Attacking:
                    Console.WriteLine("Cover Fire ");
                    break;
                case TankMode.Defending:
                    Console.WriteLine("Hide well");
                    break;
                case TankMode.Gorilla:
                    Console.WriteLine("Duck");
                    break;
            }
        }

        public void Move()
        {
            switch (_mode)
            {
                case TankMode.Attacking:
                    Console.WriteLine("Run at Enemy ");
                    break;
                case TankMode.Defending:
                    Console.WriteLine("Run away save yourself.");
                    break;
                case TankMode.Gorilla:
                    Console.WriteLine("Move hapazard");
                    break;
            }
        }


    }
}
