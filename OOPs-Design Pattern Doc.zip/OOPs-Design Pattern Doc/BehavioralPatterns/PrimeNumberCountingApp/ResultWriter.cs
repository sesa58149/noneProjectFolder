﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ConceptArchitect.MathUtils;

namespace PrimeNumberCountingApp
{
    public class ResultWriter:IResultPresenter
    {
        
        StreamWriter writer;
        public ResultWriter(string path)
        {
             writer = new StreamWriter(path);
        }

        #region IResultPresenter Members

        public void NotifyResult(object p)
        {
            writer.WriteLine(p);
            writer.Flush();
        }

        #endregion
    }
}
