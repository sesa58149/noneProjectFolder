﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using ConceptArchitect.MathUtils;

namespace PrimeNumberCountingApp
{
    class Program
    {
        static void Main(string[] args)
        {
           // IPrimeNumberCounter counter = new SimplePrimeNumberCounter();
            //EasyPrimeFinder finder = new EasyPrimeFinder();
            //FastPrimeFinder finder = new FastPrimeFinder();
            LightningFastPrimeFinder finder = new LightningFastPrimeFinder();
            IPrimeNumberCounter counter = new SmartPrimeNumberCounter(finder,new ResultWriter(@"c:\myworks\primes.txt"));

            Stopwatch watch = new Stopwatch();
            watch.Start();
            int primes = counter.CountPrimes(2, 500000);
            watch.Stop();

            Console.WriteLine("\tTotal Primes {0}\tTotal Time Taken is {1} ms",primes, watch.ElapsedMilliseconds);
        }
    }
}
