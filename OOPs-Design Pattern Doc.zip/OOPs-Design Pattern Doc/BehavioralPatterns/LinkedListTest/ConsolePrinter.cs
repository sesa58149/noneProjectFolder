﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Collections;

namespace LinkedListTest
{
    public class ConsolePrinter<T>:IVisitor<T>
    {

        #region ITask<T> Members

        public void Initalize()
        {
        }

        public void Process(T p)
        {
            Console.Write(p+"\t");
        }

        public void Close()
        {
            Console.WriteLine();
        }

        #endregion
    }
}
