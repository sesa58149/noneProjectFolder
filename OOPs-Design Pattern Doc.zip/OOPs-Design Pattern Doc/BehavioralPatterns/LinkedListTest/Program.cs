﻿using System;
//using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Collections;

namespace LinkedListTest
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<int> numbers = new LinkedList<int>();
            //DynamicArray<int> numbers = new DynamicArray<int>(5);
            
            FillList(numbers);

            numbers.ForEach(new ConsolePrinter<int>());

            numbers.ForEach(new FileWriter<int>("c:\\myworks\\numbers.txt"));

            AverageCalculator calc = new AverageCalculator();

            numbers.ForEach(calc);

            Console.WriteLine("Average is "+calc.Average);



        }

        private static void FillList(IIndexedList<int> numbers)
        {
            int[] values = { 2, 11, 9, 4, 7, 16, 21, 36, 42, 43, 55, 49, 61, 63, 11, 8 };

            foreach (int value in values)
            {
                numbers.Add(value);
               // Console.WriteLine(numbers);
            }
            Console.WriteLine("all numbers added...");
        }
    }
}
