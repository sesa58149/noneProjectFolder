﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ConceptArchitect.Collections;

namespace LinkedListTest
{
    public class FileWriter<T>:IVisitor<T>
    {
        string path;
        StreamWriter writer;
        public FileWriter(string path)
        {
            this.path = path;
        }

        public void Initalize()
        {
            writer = new StreamWriter(path);
        }

        public void Process(T p)
        {
            writer.WriteLine(p);
        }

        public void Close()
        {
            writer.Close();

        }

    }
}
