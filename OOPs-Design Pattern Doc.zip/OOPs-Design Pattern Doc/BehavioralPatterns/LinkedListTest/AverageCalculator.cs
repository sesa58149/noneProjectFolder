﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.Collections;

namespace LinkedListTest
{
    public class AverageCalculator:IVisitor<int>
    {
        int sum = 0;
        int count = 0;
        double avg = 0;
        public double Average { get { return avg; } }


        public void Initalize()
        {
        }

        public void Process(int p)
        {
            sum += p;
            count++;
        }

        public void Close()
        {
            avg = sum / count;
        }

    }
}
