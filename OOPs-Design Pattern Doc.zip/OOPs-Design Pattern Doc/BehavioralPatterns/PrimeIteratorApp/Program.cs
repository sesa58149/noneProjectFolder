﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConceptArchitect.MathUtils;

namespace PrimeIteratorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PrimeIterator it = new PrimeIterator();

            Console.WriteLine("First 10 Primes...");

            for(int i=0;i<10;i++)
            {
                Console.WriteLine("{0}\t",it.NextPrime());
            }

            Console.WriteLine();
            Console.WriteLine("First 10 Primes after 1000...");
            it.Reset(1000);

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("{0}\t", it.NextPrime());
            }
            Console.WriteLine();




        }
    }
}
