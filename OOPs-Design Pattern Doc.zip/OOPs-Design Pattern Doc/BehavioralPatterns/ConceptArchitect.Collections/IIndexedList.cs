﻿using System;
namespace ConceptArchitect.Collections
{
    public interface IIndexedList<T>
    {
        void Add(T item);
        int Count { get; }
        T this[int ndx] { get; set; }

        //Accepts a Visitor
        void ForEach(IVisitor<T> task);

        IIndexedList<T> Search(ICondition<T> c);
    }
}
