﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Collections
{
    //Interface for defining Visitor
    public interface IVisitor<T>
    {
        void Initalize();

        void Process(T p);

        void Close();
    }
}
