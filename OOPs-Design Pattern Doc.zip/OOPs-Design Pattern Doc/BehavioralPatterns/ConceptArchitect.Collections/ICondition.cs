﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Collections
{
    public interface ICondition<T>
    {
        bool IsTrue(T value);
    }
}
