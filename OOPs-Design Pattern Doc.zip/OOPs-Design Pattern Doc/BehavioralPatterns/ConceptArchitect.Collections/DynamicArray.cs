﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.Collections
{
    public class DynamicArray<T>:IIndexedList<T>
    {
        int factor;
        public int Length { get; private set; }

        T[] array;

        public int Capacity { get { return array.Length; } }

        public DynamicArray(int size)
        {
            factor = size;
            array = new T[size];

        }

        public void Add(T item)
        {
            EnsureCapacity();
            array[Length++] = item;
        }

        private void EnsureCapacity()
        {
            if(Count==Capacity)
            {
                int newSize = Capacity + factor;
                T[] newArray = new T[newSize];
                for (int i = 0; i < Capacity; i++)
                    newArray[i] = array[i];

                array = newArray;
            }
        }

        public int Count
        {
            get { return Length; }
        }

        void ValidateIndex(int ndx)
        {
            if (ndx < 0 || ndx >= Count)
                throw new IndexOutOfRangeException();
        }

        public T this[int ndx]
        {
            get
            {
                ValidateIndex(ndx);
                return array[ndx];
            }
            set
            {
                ValidateIndex(ndx);
                array[ndx] = value;
            }
        }


        public override string ToString()
        {
            if (Count == 0) return "DynamicArray(empty)";
            String str = "DynamicArray " + (Count == Capacity ? "[" : "(")+"\t";

            for (int i = 0; i < Count; i++)
                str += string.Format("{0}\t", array[i]);

                str +=  (Count == Capacity ? "]" : ")");

            return str;


        }


        public int IndexOf(T value)
        {
            int c = 0;
            for (int i = 0; i < Count;i++ )
            {
                if (array[i].Equals(value))
                    return c;
                c++;
            }
            return -1;
        }



        public void ForEach(IVisitor<T> task)
        {
            task.Initalize();
            
            for (int i = 0; i < Count; i++)
                task.Process(array[i]);
           
            task.Close();
        }



        #region IIndexedList<T> Members


        public IIndexedList<T> Search(ICondition<T> c)
        {
            DynamicArray<T> result = new DynamicArray<T>(5);
            for (int i = 0; i < Count; i++)
                if (c.IsTrue(array[i]))
                    result.Add(array[i]);

            return result;

        }

        #endregion
    }
}
