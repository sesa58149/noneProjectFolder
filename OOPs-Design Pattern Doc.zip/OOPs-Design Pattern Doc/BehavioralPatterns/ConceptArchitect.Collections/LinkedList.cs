﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;

namespace ConceptArchitect.Collections
{
   
    //template<typename T>
    public class LinkedList<T> : ConceptArchitect.Collections.IIndexedList<T> 
    {
        class Node
        {
            public T item;
            public Node next;
			public Node prev;
        }


        Node first=null;
        Node last=null;
        int count = 0;

        public int Count { get { return count; } }

        public void Add(T item)
        {
            Node n = new Node();
            n.item = item;
            n.next = null;
			n.prev=last;

            if (first == null)
			{
                first = n;
				last=n;
			}
            else
			{
                last.next = n;
			}

            last = n;
            count++;
        }

        public T this[int ndx]
        {
            get
            {
                return GetNode(ndx).item;
            }

            set
            {
                GetNode(ndx).item = value;
            }
        }

        private Node GetNode(int ndx)
        {
            if (ndx < 0 || ndx >= count)
                throw new IndexOutOfRangeException("invalid index " + ndx);

            Node n = first;
            for (int i = 0; i < ndx; i++)
                n = n.next;
            return n;
        }

        public override string ToString()
        {
            if (first == null)
                return "(empty)";

            string str = "(";

            for (Node n = first; n != null; n = n.next)
                str += "  " + n.item;

            str += "  )";

            return str;

        }


        public void Show()
        {
            for(Node n=first;n!=null;n=n.next)
            {
                Console.WriteLine(n.item);
            }
        }

        public int IndexOf(T value)
        {
            int c = 0;
            for(Node n=first;n!=null;n=n.next)
            {
                if (n.item.Equals(value))
                    return c;
                c++;
            }
            return -1;
        }

        public void WriteTo(StreamWriter writer)
        {
            for(Node n=first;n!=null;n=n.next)
            {
                writer.WriteLine(n.item);
            }
            writer.Flush();
        }

        //Visitor
        public void ForEach(IVisitor<T> task)
        {
            task.Initalize();
            for (Node n = first; n != null; n = n.next)
                task.Process(n.item);
            task.Close();
        }

        //Strategy design pattern
        public LinkedList<T> Search(ICondition<T> condition)
        {
            LinkedList<T> result = new LinkedList<T>();

            for (Node n = first; n != null; n = n.next)
                if (condition.IsTrue(n.item))
                    result.Add(n.item);


            return result;
        }

        //public int Sum()
        //{
        //    int s = 0;
        //    for (Node n = first; n != null;n=n.next )
        //    {
        //        s +=(int) n.item;
        //    }
        //    return s;
        //}

        






    }
}
