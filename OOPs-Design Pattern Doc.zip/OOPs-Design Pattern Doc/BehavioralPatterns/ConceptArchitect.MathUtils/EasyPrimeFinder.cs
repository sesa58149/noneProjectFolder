﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.MathUtils
{
    public class EasyPrimeFinder : ConceptArchitect.MathUtils.IPrimeFinder
    {
        public bool IsPrime(int number)
        {

            for (int n = 2; n < number; n++)
            {
                if (number % n == 0)
                {
                    return false;
                }
            }

            return true; ;
        }
    }
}
