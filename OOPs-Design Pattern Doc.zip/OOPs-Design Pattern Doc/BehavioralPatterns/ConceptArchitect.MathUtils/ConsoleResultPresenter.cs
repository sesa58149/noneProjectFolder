﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.MathUtils
{
    public class ConsoleResultPresenter:IResultPresenter
    {
        

        public void NotifyResult(object o)
        {
            Console.WriteLine(o);
        }

        
    }
}
