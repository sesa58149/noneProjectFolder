﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.MathUtils
{
    public class PrimeIterator
    {
        int currentValue = 1;
        EasyPrimeFinder finder = new EasyPrimeFinder();

        public int NextPrime()
        {
            //given the next Prime number
            
            do
            {
                currentValue++;
               
            } while (!finder.IsPrime(currentValue));

            return currentValue;
        }

        public void Reset(int currentValue)
        {
            this.currentValue = currentValue;
        }
    }
}
