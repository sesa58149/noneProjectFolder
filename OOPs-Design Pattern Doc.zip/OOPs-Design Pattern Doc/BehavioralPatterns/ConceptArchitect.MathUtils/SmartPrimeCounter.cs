﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.MathUtils
{

    public class   PrimeResult
    {
        public int min;
        public int max;
        public int primes;

        public PrimeResult(int min,int max,int primes)
        {
            this.min = min;
            this.max = max;
            this.primes = primes;
        }

        public override string ToString()
        {
            return string.Format("PrimeResult[{0},{1}]={2}", min, max, primes);
        }
    }

    public class SmartPrimeNumberCounter : IPrimeNumberCounter
    {


        IPrimeFinder finder;
        IResultPresenter presenter;
        
        //Client is passing the finder
        public SmartPrimeNumberCounter(IPrimeFinder finder,IResultPresenter presenter=null)
        {
            this.finder = finder;
            this.presenter = presenter ?? new ConsoleResultPresenter();//default dependency
        }


        public int CountPrimes(int min, int max)
        {
            int count = 0;//Delegate Not Call Back

            for (int i = min; i < max; i++)
            {
                if (finder.IsPrime(i)) //---> call back
                    count++;            //I don't know which IsPrime I will call
                                        //client will decide
            }

            //return count;

            presenter.NotifyResult(new PrimeResult(min,max,count));  //call back to notify
            return count;
        }



    }
    
}
