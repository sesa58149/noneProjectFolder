﻿using System;
namespace ConceptArchitect.MathUtils
{
    public interface IPrimeFinder
    {
        bool IsPrime(int number);
    }
}
