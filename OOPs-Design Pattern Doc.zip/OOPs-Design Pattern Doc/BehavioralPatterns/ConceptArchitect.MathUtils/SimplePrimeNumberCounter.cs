﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConceptArchitect.MathUtils
{
    public class SimplePrimeNumberCounter : IPrimeNumberCounter
    {
     
        //Service decides whom to delegate responsibility
        EasyPrimeFinder finder = new EasyPrimeFinder();

        public int CountPrimes(int min, int max)
        {
            int count = 0;
            
            for (int i = min; i < max; i++)
            {
                if (finder.IsPrime(i)) //forward call to the PrimeFinder object
                    count++;
            }

            return count;
        }



    }
}
